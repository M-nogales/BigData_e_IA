<?php
echo "Prueba de PHP funcionando!";
?>
